package Maini;

import java.util.*;
import java.io.*;

public class Terminal {
    public void mkdir(String NewFolderName)// b t create new folder
    {
        File dir = new File(NewFolderName);
        boolean success = dir.mkdir();
        if (success)
        {
           System.out.println("directorie were created successfully");
        }
        else
        {
           System.out.println("failed create the directorie");
        }
    }
    public void rmdir(String DeletedFolderName) //batms7 el folders ely gowaha fady mafho4 ay 7aga ya3ni
    {
        File dir = new File(DeletedFolderName);
        boolean success = dir.delete();
        if (success)
        {
           System.out.println("directory were deleted successfully");
        }
        else
        {
           System.out.println("failed delete the directory");
        }
    }
    public void cat(String FirstFileName,String SecondFilename)//concatinate two files's content and show the result
    {
        Scanner scan,scan2;
        String text=new String("");
        try{
         scan=new Scanner(new java.io.File(FirstFileName));
         while(scan.hasNext())
          {
             text+=scan.next();
          }
         
        }
        catch(Exception e){
            
            System.out.println("we can't open the first file "+e.getMessage());
        }
        text+=" ";
        try{
         scan2=new Scanner(new java.io.File(SecondFilename));
         while(scan2.hasNext())
          {
             text+=scan2.next();
          }
        }
        catch(Exception e){
            
            System.out.println("we can't open the second file "+e.getMessage());
         }
        System.out.println(text);
    }
    public void more(String DeletedFolderName)
    {
        
    }
    public void rm(String DeletedFileName) // delete a file
    {
         File file = new File(DeletedFileName);
         if(file.delete())
         {
             System.out.println("File deleted successfully");
         }
         else
         {
             System.out.println("Failed to delete the file"); 
         }
    }
    public void pwd() //show the user's current directory
    {
        String pwd = System.getProperty("user.dir");
        System.out.println(pwd);
    }
}
